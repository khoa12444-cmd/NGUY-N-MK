// Nguyễn MK Converter — logic
const inputEl = document.getElementById('inputValue');
const fromEl  = document.getElementById('unitFrom');
const toEl    = document.getElementById('unitTo');
const resEl   = document.getElementById('result');
const btn     = document.getElementById('convertBtn');

// Bật hiệu ứng lấp lánh khi đang nhập số
inputEl.addEventListener('input', () => {
  if (inputEl.value.trim() !== '') inputEl.classList.add('sparkle');
  else inputEl.classList.remove('sparkle');
});

btn.addEventListener('click', convert);

function convert(){
  const value = parseFloat(inputEl.value);
  if (isNaN(value)){
    resEl.textContent = '⚠️ Vui lòng nhập số hợp lệ!';
    return;
  }
  const from = fromEl.value;
  const to   = toEl.value;

  // Bảng quy đổi về mét
  const toMeter = {
    m: 1,
    cm: 0.01,
    mm: 0.001,
    km: 1000
  };

  // Đổi sang mét
  let meters = value * toMeter[from];
  // Từ mét sang đơn vị đích
  let result = meters / toMeter[to];

  // Làm đẹp số
  const formatted = Number.isInteger(result) ? result : +result.toFixed(6);
  resEl.textContent = `${value} ${from} = ${formatted} ${to}`;
}
